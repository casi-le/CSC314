#include <stdio.h>

int main ( )
{
	int varA = 10;


	printf("Welcome!\n");

	if(varA<=16)//if varA is less than or equal to 16, "jump" to label1
		{
			
			if(varA>9)//start of "label1" if varA is greater than 9, "jump" to label 2
				{
					printf("equal to\n");//start of "label2" prints out greater than
			
				}


			else
				{
					printf("greater than\n");		//continuation not jump of label 1
				}


		}


	else//if we don't "jump" in the first condition, print off less than
		{
			printf("less than\n");
		}


//label3

while(varA>0)
{

	varA=varA>>1;
	printf("%d \n",varA);

}

return 0;

}
